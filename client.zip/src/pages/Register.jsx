import React from "react";
import { Form, Input } from "antd";
import "../styles/RegisterStyles.css";
import { Link } from "react-router-dom";

const Register = () => {
  const onFinishHandler = (values) => {
    // alert(values);
    console.log(values);
  };

  return (
    <>
      <div className="form-container card  ">
        <Form
          layout="vertical"
          onFinish={onFinishHandler}
          className="register-form"
        >
          <h3>Register Form</h3>
          <Form.Item label="Name" name="name">
            <Input placeholder="Enter Name.." required type="text" />
          </Form.Item>
          <Form.Item label="Email" name="email">
            <Input type="text" required placeholder="Enter Email" />
          </Form.Item>
          <Form.Item label="Password" name="password">
            <Input type="password" required placeholder="Enter Password" />
          </Form.Item>
          <button className="btn btn-primary" type="submit">
            Register
          </button>
          <div className="mt-2">
            <Link to="/login">All ready Register?</Link>
          </div>
        </Form>
      </div>
    </>
  );
};

export default Register;
