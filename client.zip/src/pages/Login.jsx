import React from "react";
import "../styles/LoginStyles.css";
import { Form, Input } from "antd";
import { Link } from "react-router-dom";

const Login = () => {
  const onFinishHandler = (values) => {
    // alert(values);
    console.log(values);
  };
  return (
    <>
      <div className="form-container card  ">
        <Form
          layout="vertical"
          onFinish={onFinishHandler}
          className="register-form"
        >
          <h3>Login Form</h3>
          <Form.Item label="UserName" name="userName">
            <Input placeholder="Enter User Name.." required type="text" />
          </Form.Item>

          <Form.Item label="Password" name="password">
            <Input type="password" required placeholder="Enter Password" />
          </Form.Item>
          <button className="btn btn-primary" type="submit">
            Login
          </button>
          <div className="mt-2">
            <Link to="/register">Not Register?</Link>
          </div>
        </Form>
      </div>
    </>
  );
};

export default Login;
