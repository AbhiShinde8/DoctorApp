const express = require("express");
const color = require("colors");
const morgan = require("morgan");
const dotenv = require("dotenv");

const app = express();

// dotevent config 
dotenv.config(); //this function call require for config and connect port

// meddlewares
app.use(express.json()); // parser releted bodyParser like work
app.use(morgan("dev"));

app.get("/", function (req, res) {
  res.status(200).send({
    message: "Server Running",
  });
});

// listen port

const port = process.env.PORT || 8080;

app.listen(port, () => {
  console.log(
    `server running in ${process.env.DEV_MODE} Mode on port ${process.env.PORT} `
      .bgCyan.white
  );
});
